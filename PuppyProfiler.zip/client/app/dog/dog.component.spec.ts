import { TestBed, async } from '@angular/core/testing';
import { SharesComponent } from './shares.component';

/*describe('Component: Shares', () => {
  it('should create an instance', () => {
    let component = new SharesComponent();
    expect(component).toBeTruthy();
  });
});*/
