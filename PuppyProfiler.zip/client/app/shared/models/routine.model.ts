export class Routine {
  _id?: string;
  dog?: string;
  time?: string;
  action?: string;
  notes?: string;
}
