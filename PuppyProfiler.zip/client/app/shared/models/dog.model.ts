export class Dog {
  _id?: string;
  user?: string;
  name?: string;
  breed?: string;
  birthday?: string;
}
